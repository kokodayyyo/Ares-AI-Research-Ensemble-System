from hgs_dataset_runner import main


if __name__ == "__main__":
    raise SystemExit(main(default_dataset="val20_dataset.npy"))
