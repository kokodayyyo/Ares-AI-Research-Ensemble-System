from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


AVAILABLE_DATASETS = (
    "train50_dataset.npy",
    "val20_dataset.npy",
    "val50_dataset.npy",
    "val100_dataset.npy",
    "test20_dataset.npy",
    "test50_dataset.npy",
    "test100_dataset.npy",
)

DEFAULT_CAPACITY = 50.0
DEFAULT_TIME_LIMIT = 1.0
DEFAULT_ROUNDING = 0


@dataclass
class InstanceResult:
    index: int
    cost: float
    vrp_path: str
    solution_path: str
    log_path: str


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def dataset_root() -> Path:
    return repo_root() / "cvrp_aco" / "dataset"


def default_output_dir(dataset_name: str) -> Path:
    return repo_root() / "tools" / "results" / Path(dataset_name).stem


def iter_hgs_candidates(explicit_path: str | None) -> Iterable[Path]:
    seen: set[Path] = set()

    candidate_strings = [
        explicit_path,
        str(repo_root() / "build" / "hgs.exe"),
        str(repo_root() / "build" / "Release" / "hgs.exe"),
        str(repo_root() / "build" / "bin" / "hgs.exe"),
        str(repo_root() / "hgs.exe"),
    ]

    for env_name in ("HGS_EXE", "HGS_BIN"):
        env_text = os.environ.get(env_name)
        if env_text:
            candidate_strings.append(env_text)

    for candidate_text in candidate_strings:
        if not candidate_text:
            continue
        candidate = Path(candidate_text).expanduser()
        if not candidate.is_absolute():
            candidate = (repo_root() / candidate).resolve()
        else:
            candidate = candidate.resolve()
        if candidate not in seen:
            seen.add(candidate)
            yield candidate

    for candidate in repo_root().rglob("hgs.exe"):
        resolved = candidate.resolve()
        if resolved not in seen:
            seen.add(resolved)
            yield resolved


def resolve_hgs_path(explicit_path: str | None) -> Path:
    for candidate in iter_hgs_candidates(explicit_path):
        if candidate.is_file():
            return candidate

    searched = [str(path) for path in iter_hgs_candidates(explicit_path)]
    raise FileNotFoundError(
        "找不到 HGS 可执行文件 hgs.exe。请先编译 HGS，或者在命令里传入 "
        f"`--hgs <path-to-hgs.exe>`。\n已检查路径:\n- " + "\n- ".join(searched)
    )


def write_cvrplib_instance(instance: np.ndarray, output_path: Path, capacity: float, name: str) -> None:
    if instance.ndim != 2 or instance.shape[1] != 3:
        raise ValueError(f"实例形状不符合预期: {instance.shape}，期望为 (n_nodes, 3)")

    demands = instance[:, 0]
    coords = instance[:, 1:]
    dimension = instance.shape[0]

    with output_path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(f"NAME : {name}\n")
        handle.write("COMMENT : generated from cvrp_aco numpy dataset\n")
        handle.write("TYPE : CVRP\n")
        handle.write(f"DIMENSION : {dimension}\n")
        handle.write("EDGE_WEIGHT_TYPE : EUC_2D\n")
        handle.write(f"CAPACITY : {capacity:g}\n")
        handle.write("NODE_COORD_SECTION\n")
        for node_id, (x_coord, y_coord) in enumerate(coords, start=1):
            handle.write(f"{node_id} {x_coord:.12f} {y_coord:.12f}\n")
        handle.write("DEMAND_SECTION\n")
        for node_id, demand in enumerate(demands, start=1):
            handle.write(f"{node_id} {int(round(float(demand)))}\n")
        handle.write("DEPOT_SECTION\n")
        handle.write("1\n")
        handle.write("-1\n")
        handle.write("EOF\n")


def parse_solution_cost(solution_path: Path) -> float:
    for line in reversed(solution_path.read_text(encoding="utf-8").splitlines()):
        if line.startswith("Cost "):
            return float(line.split()[1])
    raise ValueError(f"未能在解文件中找到 Cost 行: {solution_path}")


def run_hgs(
    hgs_path: Path,
    instance_path: Path,
    solution_path: Path,
    log_path: Path,
    time_limit: float,
    seed: int,
    rounding: int,
    verbose_log: int,
) -> float:
    command = [
        str(hgs_path),
        str(instance_path),
        str(solution_path),
        "-seed",
        str(seed),
        "-t",
        str(time_limit),
        "-round",
        str(rounding),
        "-log",
        str(verbose_log),
    ]

    completed = subprocess.run(
        command,
        cwd=repo_root(),
        capture_output=True,
        text=True,
        check=False,
    )
    log_path.write_text(completed.stdout + completed.stderr, encoding="utf-8")

    if completed.returncode != 0:
        raise RuntimeError(
            f"HGS 运行失败，退出码 {completed.returncode}，详情见日志: {log_path}"
        )
    if not solution_path.is_file():
        raise RuntimeError(f"HGS 未生成解文件: {solution_path}")

    return parse_solution_cost(solution_path)


def ensure_output_dirs(output_dir: Path) -> tuple[Path, Path, Path]:
    vrp_dir = output_dir / "instances"
    sol_dir = output_dir / "solutions"
    log_dir = output_dir / "logs"
    vrp_dir.mkdir(parents=True, exist_ok=True)
    sol_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    return vrp_dir, sol_dir, log_dir


def load_dataset(dataset_name: str) -> np.ndarray:
    dataset_path = dataset_root() / dataset_name
    if not dataset_path.is_file():
        raise FileNotFoundError(f"数据集不存在: {dataset_path}")

    dataset = np.load(dataset_path)
    if dataset.ndim != 3 or dataset.shape[2] != 3:
        raise ValueError(f"数据集形状不符合预期: {dataset.shape}，期望为 (m, n_nodes, 3)")
    return dataset


def save_summary(
    summary_path: Path,
    dataset_name: str,
    hgs_path: Path,
    time_limit: float,
    seed: int,
    capacity: float,
    rounding: int,
    results: list[InstanceResult],
) -> None:
    costs = [result.cost for result in results]
    payload = {
        "dataset": dataset_name,
        "hgs_path": str(hgs_path),
        "time_limit": time_limit,
        "seed": seed,
        "capacity": capacity,
        "rounding": rounding,
        "instance_count": len(results),
        "mean_cost": float(np.mean(costs)) if costs else None,
        "min_cost": float(np.min(costs)) if costs else None,
        "max_cost": float(np.max(costs)) if costs else None,
        "results": [asdict(result) for result in results],
    }
    summary_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def save_csv(csv_path: Path, results: list[InstanceResult]) -> None:
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["index", "cost", "vrp_path", "solution_path", "log_path"],
        )
        writer.writeheader()
        for result in results:
            writer.writerow(asdict(result))


def solve_dataset(
    dataset_name: str,
    hgs_path: Path,
    output_dir: Path,
    time_limit: float,
    seed: int,
    capacity: float,
    rounding: int,
    limit: int | None,
    force: bool,
    verbose_log: int,
) -> list[InstanceResult]:
    dataset = load_dataset(dataset_name)
    if limit is not None:
        dataset = dataset[:limit]

    vrp_dir, sol_dir, log_dir = ensure_output_dirs(output_dir)
    results: list[InstanceResult] = []

    total = len(dataset)
    for index, instance in enumerate(dataset):
        file_stem = f"instance_{index:03d}"
        instance_path = vrp_dir / f"{file_stem}.vrp"
        solution_path = sol_dir / f"{file_stem}.sol"
        log_path = log_dir / f"{file_stem}.log"

        write_cvrplib_instance(
            instance=instance,
            output_path=instance_path,
            capacity=capacity,
            name=f"{Path(dataset_name).stem}_{index:03d}",
        )

        if solution_path.is_file() and not force:
            cost = parse_solution_cost(solution_path)
            status = "reuse"
        else:
            cost = run_hgs(
                hgs_path=hgs_path,
                instance_path=instance_path,
                solution_path=solution_path,
                log_path=log_path,
                time_limit=time_limit,
                seed=seed,
                rounding=rounding,
                verbose_log=verbose_log,
            )
            status = "solve"

        results.append(
            InstanceResult(
                index=index,
                cost=cost,
                vrp_path=str(instance_path),
                solution_path=str(solution_path),
                log_path=str(log_path),
            )
        )
        print(f"[{index + 1}/{total}] {status} cost={cost:.6f}")

    return results


def build_parser(default_dataset: str | None = None) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Convert cvrp_aco numpy datasets to CVRPLIB instances and solve them with HGS."
    )
    if default_dataset is None:
        parser.add_argument(
            "--dataset",
            required=True,
            choices=AVAILABLE_DATASETS,
            help="要运行的 numpy 数据集文件名",
        )
    parser.add_argument(
        "--hgs",
        default=None,
        help="hgs.exe 路径；如果不传，脚本会在仓库里自动查找",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="输出目录；默认写到 tools/results/<dataset_name>",
    )
    parser.add_argument(
        "--time-limit",
        type=float,
        default=DEFAULT_TIME_LIMIT,
        help=f"每个实例的 HGS 时间上限（秒），默认 {DEFAULT_TIME_LIMIT}",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=0,
        help="HGS 随机种子，默认 0",
    )
    parser.add_argument(
        "--capacity",
        type=float,
        default=DEFAULT_CAPACITY,
        help=f"车辆容量，默认 {DEFAULT_CAPACITY:g}",
    )
    parser.add_argument(
        "--round",
        type=int,
        choices=(0, 1),
        default=DEFAULT_ROUNDING,
        help="HGS 距离取整开关；对 cvrp_aco 数据建议用 0，默认 0",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="只跑前 N 个实例，便于快速测试",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="即使已有 .sol 文件，也强制重新求解",
    )
    parser.add_argument(
        "--log",
        type=int,
        choices=(0, 1),
        default=0,
        help="是否开启 HGS 自身的详细日志，默认 0",
    )

    if default_dataset is not None:
        parser.set_defaults(dataset=default_dataset)
    return parser


def main(argv: list[str] | None = None, default_dataset: str | None = None) -> int:
    parser = build_parser(default_dataset=default_dataset)
    args = parser.parse_args(argv)

    dataset_name = args.dataset
    output_dir = (
        Path(args.output_dir).resolve()
        if args.output_dir
        else default_output_dir(dataset_name)
    )
    hgs_path = resolve_hgs_path(args.hgs)

    results = solve_dataset(
        dataset_name=dataset_name,
        hgs_path=hgs_path,
        output_dir=output_dir,
        time_limit=args.time_limit,
        seed=args.seed,
        capacity=args.capacity,
        rounding=args.round,
        limit=args.limit,
        force=args.force,
        verbose_log=args.log,
    )

    save_csv(output_dir / "summary.csv", results)
    save_summary(
        summary_path=output_dir / "summary.json",
        dataset_name=dataset_name,
        hgs_path=hgs_path,
        time_limit=args.time_limit,
        seed=args.seed,
        capacity=args.capacity,
        rounding=args.round,
        results=results,
    )

    mean_cost = float(np.mean([result.cost for result in results])) if results else float("nan")
    print(f"dataset={dataset_name}")
    print(f"hgs={hgs_path}")
    print(f"output_dir={output_dir}")
    print(f"mean_cost={mean_cost:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
